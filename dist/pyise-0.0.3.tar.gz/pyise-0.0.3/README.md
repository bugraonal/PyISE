# PyISE
This is a Python wrapper for Xilinx ISE with the added functionality of batch synthesis and simulation. The console output of batch operations are logged.
